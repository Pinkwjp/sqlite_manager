# sqlite_manager
a small package for sqlite executions
